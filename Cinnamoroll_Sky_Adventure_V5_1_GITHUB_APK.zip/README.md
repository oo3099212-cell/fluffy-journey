# Cinnamoroll Sky Adventure V5.1 — APK con GitHub Actions

Este repositorio contiene la versión web del juego dentro de `www/index.html` y una configuración de Capacitor para compilarla como aplicación Android.

## Crear el APK desde GitHub

1. Crea un repositorio nuevo en GitHub. Puede ser privado.
2. Sube **todo el contenido de esta carpeta**, incluyendo la carpeta oculta `.github`.
3. Usa `main` como rama principal.
4. En GitHub abre la pestaña **Actions**.
5. Abre el workflow **Crear APK Android**.
6. Pulsa **Run workflow** y confirma con **Run workflow**.
7. Espera a que el proceso termine con una marca verde.
8. Abre la ejecución terminada.
9. Baja hasta **Artifacts**.
10. Descarga **Cinnamoroll-Sky-Adventure-V5.1-APK**.
11. Descomprime el archivo descargado y encontrarás:

   `Cinnamoroll-Sky-Adventure-V5.1-debug.apk`

Ese APK se puede instalar en Android para pruebas.

## Actualizar el juego

Para una nueva versión, normalmente solo debes reemplazar:

`www/index.html`

Después haz commit/push a `main`. GitHub Actions volverá a compilar automáticamente un APK nuevo.

## Estructura

```text
.
├── .github/
│   └── workflows/
│       └── build-apk.yml
├── www/
│   └── index.html
├── capacitor.config.json
├── package.json
├── .gitignore
└── README.md
```

## Datos de la app

- Nombre: **Cinnamoroll Sky Adventure**
- App ID: `com.diego.cinnamorollskyadventure`
- Capacitor: 8.x
- Android mínimo de Capacitor 8: API 24+
- El workflow compila contra Android API 36.

## Importante

El APK generado por este workflow es una versión **debug** para instalar y probar. Para publicar en Google Play se necesita generar un **AAB de release firmado** con una clave privada (`keystore`). No subas una keystore ni sus contraseñas directamente al repositorio.
